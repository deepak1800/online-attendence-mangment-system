
public class Salaried extends Employee {
    public double monthlySalary;
    public Salaried(String name,String id,String designation,Double monthlySalary){
        super(name,id,designation);
        this.monthlySalary = monthlySalary;
    }
    @Override
    public double getSalary(){
        return monthlySalary;
    }
    @Override
    public void increaseSalary(double amt) throws InvalidSalaryException{
        if(amt<=0)
            throw new InvalidSalaryException("Increase amount should be a positive number.");
        monthlySalary += amt;
    }
    @Override
    public void display(){
        super.display();
        System.out.println("Salary: "+monthlySalary);
    }
}
