# Employee Management System
Educational project for understaning JAVA better!
