
public class InvalidSalary extends Exception {

    public InvalidSalary(String message) {
        super(message);
    }
}
